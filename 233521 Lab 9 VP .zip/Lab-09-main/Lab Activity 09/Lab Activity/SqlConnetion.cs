﻿namespace Lab_Activity
{
    internal class SqlConnetion
    {
        private string sqlConnetion;

        public SqlConnetion(string sqlConnetion)
        {
            this.sqlConnetion = sqlConnetion;
        }

        internal void Open()
        {
            throw new NotImplementedException();
        }
    }
}